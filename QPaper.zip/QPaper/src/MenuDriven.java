import java.util.Scanner;

class Person{
	String name;
	String dateOfBirth;
	//MyDate dateOfBirth;
	
	public Person() {
		
	}
	public Person(String name) {
		this.name=name;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + "]";
	}
}

class Employee extends Person{
	int id;
	String department;
	double salary;
	String dateOfJoining;
	//MyDate dateOfBirth;
	
	public Employee() {
		
	}
	public Employee(int id, String department, double salary) {
		super();
		this.id = id;
		this.department = department;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", department=" + department + ", salary=" + salary + "]";
	}
}

class MyDate extends Employee{
	int day;
	int month;
	int year;
	
	public MyDate() {
		
	}
	public MyDate(int day,int month,int year) {
		this.day=day;
		this.month=month;
		this.year=year;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	@Override
	public String toString() {
		return "MyDate [day=" + day + ", month=" + month + ", year=" + year + "]";
	}
}
public class MenuDriven {

	public static void main(String[] args) {
		System.out.println("MenuList---");
		System.out.println("1.Add Employee");
		System.out.println("2.Display All Employees");
		System.out.println("3.Search Employee By ID:");
		System.out.println("4.Display Employees Joined in Given Year:");
		System.out.println("Find Employee With Maximum Salary:");
		System.out.println("5.Find Employee With Minimum Salary:");
		System.out.println("7.Exit The Application");
		
		System.out.println();
		System.out.println("Enter your choice:");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
	}

}
