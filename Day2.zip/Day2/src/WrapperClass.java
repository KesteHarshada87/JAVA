
public class WrapperClass {

	public static void main(String[] args) {
		int a=20;
		Integer b=a;
		int c=b.intValue();
		System.out.println(c);
		
		String octalString=Integer.toOctalString(c);
        System.out.println(octalString);
        
        String binaryString=Integer.toBinaryString(c);
        System.out.println(binaryString);
        
        String hexString=Integer.toHexString(c);
        System.out.println(hexString);
        
	}

}
