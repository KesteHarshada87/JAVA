
public class NarrowWidening {

	public static void main(String[] args) {
		int a=10;
		System.out.println("Integer value:"+a);
		float b=a;//widening
		System.out.println("Float value:"+b);
		
		//widening
		double c=50.000;
		System.out.println("Double value:"+c);
		float d=(float) c;
		System.out.println("Float value:"+d);
		int e=(int) c;
		System.out.println("Integer value:"+e);
		short f=(short) c;
		System.out.println("Float value:"+f);
		byte g=(byte) c;
		System.out.println("Byte value:"+g);
	}

}
