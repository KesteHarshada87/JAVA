
public class Program {

	public static void main(String[] args) {
		int a=10;
		Integer b=a;//boxing
		System.out.println(b);
		
		int c=b;//unboxing
		System.out.println(c);
		
		double d=b.doubleValue();//integer to double
		System.out.println(d);
		
		byte byt=b.byteValue();//integer to byte
		System.out.println(byt);
        
		float f=b.floatValue();//integer to float
		System.out.println(f);
		
		short s=b.shortValue();
		System.out.println(s);
	}

}
