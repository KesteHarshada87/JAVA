package dkte.interface1;

interface Printable{
	int num=10;
	void print();
}

class Test implements Printable{
	public void print() {
		System.out.println("Number:"+Printable.num);
	}
}
public class Simple {

	public static void main(String[] args) {
		Printable p=new Test();
		p.print();

	}

}
