import java.util.Scanner;

 class Tester{
	protected int x;
	protected int y;
	
	public Tester() {
		
	}
	
	public Tester(int x,int y) {
		this.x=x;
		this.y=y;
	}
	
	public void acceptRecord() {
		Scanner sc=new Scanner(System.in);
		System.out.println("How many points you have to enter?");
		int size=sc.nextInt();
		int[] arr1=new int[size];
		int[] arr2=new int[size]; 
		
		for(int i=0;i<size;i++) {
			System.out.println("Enter x coordinate:");
			arr1[i]=sc.nextInt();
			System.out.println("Enter y coordinate:");
			arr2[i]=sc.nextInt();
		}
		
		System.out.println();
		System.out.println("MenuList---");
		System.out.println("0.Exit");
		System.out.println("1.Display details of a specific point");
		System.out.println("2.Display x, y co-ordinates of all points");
		System.out.println("3. User i/p : 2 indices for the points , validate the indices");
		int choice=0;
		while(choice<4) {
			System.out.println("Enter your choice:");
			choice=sc.nextInt();
		switch(choice) {
		case 0:
			System.out.println("Exit");
			break;
			
		case 1:
			System.out.println("Enter point number you want:");
			int n=sc.nextInt();
			if(n<=size) {
				System.out.println("Points:");
				System.out.println("X: "+arr1[n]);
				System.out.println("Y :"+arr2[n]);
			}
			else {
				System.out.println("Invalid index");
			}
			break;
			
		case 2:
			System.out.println("All coordinates:");
			for(int i=0;i<size;i++) {
				System.out.println("X coordinates:"+arr1[i]);
			}
			for(int i=0;i<size;i++) {
				System.out.println("Y coordinates:"+arr2[i]);
			}
			break;
			
		case 3:
			System.out.println("Enter coordinates whose distance you are going to calculate:");
			System.out.println("Enter first index:");
			int choice1=sc.nextInt();
			System.out.println("Enter second index:");
			int choice2=sc.nextInt();
			if(choice1<0 && choice1>arr1.length || choice2<0 && choice2>arr2.length) {
				System.out.println("Invalid choice!!");
			}
			
			String str1=Integer.toString(arr1[choice1]);
			String str2=Integer.toString(arr2[choice1]);
			String str3=Integer.toString(arr1[choice2]);
			String str4=Integer.toString(arr2[choice2]);
			if(str1.equals(str2) && str3.equals(str4)) {
				System.out.println("Both coordinates are equal");
			}
			else {
				double distance=Math.sqrt(Math.pow(arr1[choice1]-arr2[choice1], 2)+Math.pow(arr1[choice2]-arr2[choice2], 2));
				System.out.println("Distance between two points:"+distance);
			}
			break;
		}
		}
		System.out.println("Program terminated");
	}
}
public class Point2D {

	public static void main(String[] args) {
		Tester t=new Tester();
		t.acceptRecord();

	}

}
