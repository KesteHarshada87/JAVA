import java.util.Scanner;

class Information{
	protected int miles;
	protected double cost;
	protected double aMiles;
	protected double pfees;
	protected double tollC;
	
	public Information() {
		
	}
	
	public Information(int miles,double cost,double aMiles,float pfees,float tollC) {
		this.miles=miles;
		this.cost=cost;
		this.aMiles=aMiles;
		this.pfees=pfees;
		this.tollC=tollC;
	}
	
	public void acceptRecord() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter total miles per day:");
		miles=sc.nextInt();
		System.out.println("Enter cost per gallon of gasolin:");
		cost=sc.nextDouble();
		System.out.println("Enter avarage miles per gallon :");
		aMiles=sc.nextDouble();
		System.out.println("Enter parking fees:");
		pfees=sc.nextDouble();
		System.out.println("Enter tolls per day:");
		tollC=sc.nextDouble();
		}
	
	public void printRecord() {
		System.out.println("Miles:"+this.miles);
		double tMC=+this.miles*+this.cost;
		System.out.println("Cost required for gasolin:"+this.miles*+this.cost);
		System.out.printf("Total cost:%f",+tMC+this.pfees+this.tollC);
		
	}
}
public class Application {

	public static void main(String[] args) {
		Information I=new Information();
		I.acceptRecord();
		I.printRecord();

	}

}
