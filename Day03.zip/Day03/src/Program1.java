
import java.util.Scanner;
import java.util.Calendar;

class Date{
	private int Day;
	private int Month;
	private int Year;
	
	public void initDate() {
		Calendar c=Calendar.getInstance();
		Day=c.get(Calendar.DATE);
		Month=c.get(Calendar.MONTH);
		Year=c.get(Calendar.YEAR);
		
	}
	
	public void acceptRecord() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter day:");
		Day=sc.nextInt();
		System.out.println("Enter month:");
		Month=sc.nextInt();
		System.out.println("Enter year");
		Year=sc.nextInt();
		}
	
	public void printRecord() {
		System.out.println("Day:" +this.Day);
		System.out.println("Month:"+this.Month);
		System.out.println("Year:"+this.Year);
	}
}
public class Program1 {

	public static void main(String[] args) {
		Date dt1=new Date();
		
		dt1.initDate();
		dt1.printRecord();
        dt1.acceptRecord();
        dt1.printRecord();
        
	}

}
