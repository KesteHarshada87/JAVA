package Constructor;

import java.util.Calendar;
import java.util.Scanner;

class Date{
	private int day;
	private int month;
	private int year;
	
	public Date() {
		Calendar c=Calendar.getInstance();
		day=c.get(Calendar.DATE);
		month=c.get(Calendar.MONTH);
		year=c.get(Calendar.YEAR);
	}
	
	public Date(int day,int month,int year) {
		this.day=day;
		this.month=month;
		this.year=year;
	}
	
	public void printRecord() {
		System.out.println("Day:"+this.day);
		System.out.println("Month:"+this.month);
		System.out.println("Year:"+this.year);
	}
}

public class Program {

	public static void main(String[] args) {
		Date dt1=new Date();
		dt1.printRecord();
        Date dt2=new Date(2,5,2004);
        dt2.printRecord();
	}

}
