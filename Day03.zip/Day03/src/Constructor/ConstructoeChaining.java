package Constructor;

class Person{
	private String name;
	private int marks;
	public Person() {
		this("Harshada",87);
	}
	public Person(String name,int marks) {
		this.name=name;
		this.marks=marks;
	}
	
	public void printRecord()
	{
		System.out.println("Name is:"+this.name);
		System.out.println("Marks are:"+this.marks);
	}
}

public class ConstructoeChaining {

	public static void main(String[] args) {
		Person p=new Person();
		p.printRecord();

	}

}
