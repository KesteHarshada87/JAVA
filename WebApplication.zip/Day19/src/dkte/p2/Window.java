package dkte.p2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Window extends JFrame {
	JButton submitButton;
	JButton cancelButton;

	public Window() {
		this.setTitle("Components");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(null); // do not apply any layout

		submitButton = new JButton("Submit"); // It creates the new button component
		submitButton.setBounds(50, 50, 80, 30); // add the bounds to the button
		this.add(submitButton); // adds the component inside the window

		cancelButton = new JButton("Cancel");
		cancelButton.setBounds(150, 50, 80, 30);
		this.add(cancelButton);

		submitButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("Submit Button Clicked");
			}
		});

		cancelButton.addActionListener(e -> {
			System.out.println("Cancel Button Clicked");
		});
	}

}
