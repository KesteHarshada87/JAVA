package dkte.p1;

import javax.swing.JFrame;

public class Window extends JFrame {
	public Window() {
		this.setTitle("First Window");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
}