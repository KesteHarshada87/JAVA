package dkte.college3;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class Program {

	public static void main(String[] args) {
		List<Movies> list = new ArrayList<>();
		list.add(new Movies(1, "Star Wars", 7.5));
		list.add(new Movies(2, "Godfather", 8.0));
		list.add(new Movies(3, "Hidden Figures", 7.0));
		list.add(new Movies(4, "Bruce Almighty", 6.5));
		list.add(new Movies(5, "Forest Gump", 8.5));
		
		try(FileOutputStream fout = new FileOutputStream("Movies.db")){
			try(PrintStream out = new PrintStream(fout)){
				for(Movies m : list) {
					out.printf("%-20d%-15s%.2f\n",m.getId(),m.getTitle(),m.getRating()); 
				}
			}//out.close();
			System.out.println("Movies saved..");
		}//fout.close(); 
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
