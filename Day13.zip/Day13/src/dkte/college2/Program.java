package dkte.college2;

import java.io.BufferedOutputStream;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class Program {

	public static void main(String[] args) {
	

	}
	public static void readMovies() {
		try(FileInputStream fin=new FileInputStream("Movies.db")){
			try(BufferedInputStream bin=new BufferedInputStream(fin)){
				try(DataInputStream din=new DataInputStream(bin)){
					while(true) {
						Movies m=new Movies();
						m.setId(din.readInt());
						m.setTitle(din.readUTF());
						m.setRating(din.readDouble());
					}
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void writeMovies() {
		List<Movies> list=new ArrayList<Movies>();
		
		try(FileOutputStream fout=new FileOutputStream("Movies.db")){
			try(BufferedOutputStream bout=new BufferedOutputStream(fout)){
			try(DataOutputStream dout=new DataOutputStream(bout)){
				for(Movies m:list) {
					dout.writeInt(m.getId());
					dout.writeUTF(m.getTitle());
					dout.writeDouble(m.getRating());
				}
			}
			}
			System.out.println("Movies saved..");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
