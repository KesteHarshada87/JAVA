package dakte.college1;

import java.io.ObjectInput;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;
import java.util.ArrayList;

public class Program {

	public static void main(String[] args) {
		//writeMovies();
		readMovies();

	}
	
	public static void readMovies() {
		List<Movies> list=new ArrayList<>();
		
		try(FileInputStream fin=new FileInputStream("Movies.db")){
			try(ObjectInputStream oin=new ObjectInputStream(fin)){
				list=(List<Movies>) oin.readObject();
			}
		}catch(Exception e) {
			
		}
		System.out.println("Movies list : ");
		list.forEach(e -> System.out.println(e));
	}
	
	public static void writeMovies() {
		List<Movies> list=new ArrayList<>();
		
		try(FileOutputStream fout=new FileOutputStream("Movies.db")){
			try(ObjectOutputStream oout=new ObjectOutputStream(fout)){
				oout.writeObject(oout);
			}
			System.out.println("Movies saved...");
		}
		catch(Exception e) {
		
		}
	}

}
