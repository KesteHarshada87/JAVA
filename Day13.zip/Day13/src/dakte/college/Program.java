package dakte.college;

import java.util.ArrayList;
import java.util.List;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;;

public class Program {

	public static void main(String[] args) {
		//writeMovies();
		readMovies();

	}
	
	public static void readMovies() {
		List<Movies> list=new ArrayList<>();
		
		try(FileInputStream fin=new FileInputStream("Movies.db")){
			try(DataInputStream din=new DataInputStream(fin)) {
				while(true) {
					Movies m=new Movies();
					m.setId(din.readInt());
					m.setTitle(din.readUTF());
					m.setRating(din.readDouble());
				}
			}
		}catch(Exception e) {
			
		}
		
		list.forEach(e-> System.out.println(e));
	}
	
	public static void writeMovies() {
		List<Movies> list=new ArrayList<>();
		list.add(new Movies(1, "Star Wars", 7.5));
		list.add(new Movies(2, "Godfather", 8.0));
		list.add(new Movies(3, "Hidden Figures", 7.0));
		list.add(new Movies(4, "Bruce Almighty", 6.5));
		list.add(new Movies(5, "Forest Gump", 8.5));
		
		try(FileOutputStream fout=new FileOutputStream("Movies.db")){
			try(DataOutputStream dout=new DataOutputStream(fout)){
				for(Movies m:list) {
					dout.writeInt(m.getId());
					dout.writeUTF(m.getTitle());
					dout.writeDouble(m.getRating());
				}
			}
			System.out.println("Movies saved..");
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
