package twoDarray;
import java.util.Scanner;

public class TwoDarray {

	public static void main(String[] args) {
		int[][] arr=new int[3][3];
		int[] arr1[]=new int[3][3];
		double[][] arr3= new double[][] {{1,2},{2,3}};
		
		System.out.println("Enter array elements:");
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				Scanner sc=new Scanner(System.in); 
				arr[i][j]=sc.nextInt();
					
				
			}
		}
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				System.out.print(" "+arr[i][j]);
			}
			System.out.println();
		}
	
	}
	
	
}
