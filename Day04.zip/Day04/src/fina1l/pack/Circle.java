package fina1l.pack;

public class Circle {
	private double radius;
	private final double PI=3.14;
	
	public Circle() {
		
	}
	
	public Circle(double radius) {
		this.radius=radius;
	}
	
	public double getRadius() {
		return radius;
	}
	
	public void setRadius(double radius) {
		this.radius=radius;
	}
	
	public double getPI() {
		return PI;
	}
	
	public double calcArea() {
		return PI*this.radius*this.radius;
	}
	
	public double calcPerimeter() {
		return 2*PI*radius;
	}
	
	
	

}
