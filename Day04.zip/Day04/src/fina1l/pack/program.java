package fina1l.pack;

public class program {

	public static void main(String[] args) {
		Circle c1 = new Circle(3.1); 
		
		System.out.println("Area : "+c1.calcArea());
		System.out.println("Peri : "+c1.calcPerimeter());
		
		
		final Circle c2 = new Circle(4.1); //reference is final 
		System.out.println("Area : "+c2.calcArea());
		System.out.println("Peri : "+c2.calcPerimeter());
		
		final int x = 10; // final local variable 
	}

}
