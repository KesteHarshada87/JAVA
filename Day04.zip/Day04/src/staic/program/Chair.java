package staic.program;


public class Chair {
	private int height,weight;
	private static int price=500;
	
	public Chair(){
		
	}
	
	public Chair(int height,int weight) {
		this.height=height;
		this.weight=weight;
	}
	
	public static int getPrice() {
		return price;
	}
	
	public static void setPrice(int price) {
		Chair.price=price;
	}
	
	public void display() {
		System.out.printf("Weight : %d Height : %d Price : %d\n",this.weight,this.height,Chair.price);
	}

}
