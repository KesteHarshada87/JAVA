package staic.program;

public class Program {

	public static void main(String[] args) {
		Chair c1=new Chair(30,40);
		Chair c2=new Chair(40,50);
		
		c1.display();
		c2.display();
		
		Chair.setPrice(1000);
		c1.display();
		c2.display();
		
		

	}

}
