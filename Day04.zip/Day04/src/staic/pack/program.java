package staic.pack;

public class program {

	public static void main(String[] args) {
		Chair c1=new Chair(30,40);
		Chair c2=new Chair(10,30);
		
		c1.display();
		c2.display();

	}

}
