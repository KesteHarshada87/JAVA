package staic.pack;

public class Chair {
	private int weight;
	private int height;
	
	private static int price;
	
	public Chair() {
		
	}
	
	public Chair(int weight,int height) {
		this.weight=weight;
		this.height=height;
	}
	
	static {
		price=500;
		System.out.println("Block -- 1");
	}
	static {
		price=1000;
		System.out.println("Block -- 2");
	}
	
	public static int getPrice() {
		return price;
	}
	
	public static void setPrice(int price) {
		Chair.price=price;
	}
	
	public void display() {
		System.out.printf("Weight:%d Height:%d Price:%d",this.weight,this.height,Chair.price);
	}
}
