

import java.util.Scanner;

class Fruit{
	String name;
	String colour;
	double weight;
	boolean isFresh;
	
	public Fruit() {
		
	}
	public Fruit(String name, String colour, double weight, boolean isFresh) {
		this.name = name;
		this.colour = colour;
		this.weight = weight;
		this.isFresh = isFresh;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public boolean isFresh() {
		return isFresh;
	}
	public void setFresh(boolean isFresh) {
		this.isFresh = isFresh;
	}
	@Override
	public String toString() {
		return "Fruit [name=" + name + ", colour=" + colour + ", weight=" + weight + ", isFresh=" + isFresh + "]";
	}
	
	public String taste() {
		return "no specific taste";
		
	}
	
}

class Apple extends Fruit{

	public Apple() {
	
	}

	public Apple(String name, String colour, double weight, boolean isFresh) {
		super(name, colour, weight, isFresh);
	}
	
	public String taste() {
		return "sweet and sour";
	}

	@Override
	public String toString() {
		return "Apple [name=" + name + ", colour=" + colour + ", weight=" + weight + ", isFresh=" + isFresh
				+ "]";
	}
	
}

class Orange extends Fruit{

	public Orange() {
	
	}

	public Orange(String name, String colour, double weight, boolean isFresh) {
		super(name, colour, weight, isFresh);
	}
	
	public String taste() {
		return "sour";
	}

	@Override
	public String toString() {
		return "Orange [name=" + name + ", colour=" + colour + ", weight=" + weight + ", isFresh=" + isFresh
				+ "]";
	}
	
}

class Mango extends Fruit{

	public Mango() {
		
	}

	public Mango(String name, String colour, double weight, boolean isFresh) {
		super(name, colour, weight, isFresh);
	}
	
	public String taste() {
		return "sweet";
	}
	
	@Override
	public String toString() {
		return "Mango [name=" + name + ", colour=" + colour + ", weight=" + weight + ", isFresh=" + isFresh
				+ "]";
	}
	
}
public class FruitBasket {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of fruits: ");
        int num = sc.nextInt();
        Fruit[] basket = new Fruit[num];
        
        System.out.println("Choose fruit to add:");
        System.out.println("0.Exit");
        System.out.println("1.Add Mango");
        System.out.println("2.Add Orange");
        System.out.println("3.Add Apple");
        System.out.println("4.Name of all fruits in baskete");
        System.out.println("5.All information of fruits in basket");
        System.out.println("6.Mark a fruit as stale");
        System.out.println("7.Taste of all stale fruits");
        int counter=0;
        for (int i = 0; i<=7; i++) {
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();

            switch(choice) {
            case 0:
            	System.out.println("Exit");
            case 1:
            	if(counter<=num) {
            	basket[counter++]=new Mango("Mango","Red",20,true);
            	System.out.println("Mango is added in basket");
            	}else {
            		System.out.println("Basket is full");
            	}
            	System.out.println();
 
            	break;
            	
            case 2:
            	if(counter<=num) {
            	basket[counter++]=new Orange("Orange","Orange",10,true);
            	System.out.println("Orange is added in basket");
            	}else {
            		System.out.println("Basket is full");
            	}
            	
            	break;
            case 3:
            	if(counter<=num) {
                	basket[counter++]=new Apple("Apple","Red",15,true);
                	System.out.println("Apple is added in basket");
                	}else {
                		System.out.println("Basket is full");
                	}
            	
            	break;
            case 4:
            	System.out.println("Name of all fruits in basket:");
            	for(Fruit f1:basket) {
            		System.out.println(f1.getName());
            	}
            	break;
            case 5:
            	System.out.println("All information of fruits in basket:");
            	for(Fruit f3: basket) {
            		System.out.println(f3.toString());
            		System.out.println(f3.taste());
            	}
            	break;
            case 6:
            	System.out.println("Mark a fruit as stale");
            	System.out.println("Enter index:");
            	int index=sc.nextInt();
            	if(index>num) {
            		System.out.println("Invalid index");
            	}else {
            		basket[index].setFresh(false);
            		System.out.println(index+" no. marked as stale ");
            	}
            	break;
            case 7:
            	System.out.println("Taste of all stale fruits:");
            	for(Fruit f4:basket) {
            		if(f4 !=null && !f4.isFresh) {
            			System.out.println(f4.getName()+" "+f4.taste());
            		}
            	}
            	break;
	       default:
            	System.out.println("Invalid choice");
            }
        }
           
        
	}
	

}