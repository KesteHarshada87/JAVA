import java.util.ArrayList;
import java.util.Date;
import java.util.List;

class Box<T extends Number>{
	private T obj;
	
	public T getObj() {
		return obj;
	}
	
	public void setObj(T obj) {
		this.obj=obj;
	}
	
}

public class GenericClass {

	public static void main(String[] args) {
		Box<Integer> b=new Box<Integer>();
		b.setObj(new Integer(11));
		Integer r1=b.getObj();
		System.out.println(r1);
		
		//Box<Date> d=new Box<Date>();//not valid because date is not subclass of number
		
		Box<Double> d=new Box<Double>();
		d.setObj(new Double(11.11));
		Double r2=d.getObj();
		System.out.println(r2);
	}

}
