public class Program02 {
	
	//from java 1.0
		public static void printArray(Object[] arr ) {
			for(int i=0;i<arr.length;i++) {
				System.out.println(arr[i]);
			}
		}
	    
	//from java 5.0
		public static <T> void printArray1(T[] arr){
			for(int j=0;j<arr.length;j++) {
				T ele=arr[j];
				System.out.println(ele);
			}
		}
		
		public static<T extends Number> void printArray2(T[] arr) {
			for(int k=0;k<arr.length;k++) {
				T ele1=arr[k];
				System.out.println(ele1);
			}
		}
	/*public static void main2(String[] args) {
		Object[] arr= {11,22,22,33,33};
		printArray(arr);
	}
	public static void main1(String[] args) {
		Integer[] ele= {1,2,3,4};
		printArray1(ele);
		
		String[] ele1= {"h" ,"a","r"};
		printArray1(ele1);
	}*/
	public static void main(String[] args) {
		Integer[] ele= {1,2,3,4};
		printArray2(ele);
		
		//complile time error occurs here because T is extends as Number
		//String[] ele1= {"h" ,"a","r"};
		//printArray2(ele1);
	}
}
