package college.dkte1;

import java.util.Arrays;
import java.util.Comparator;

public class Program {

	public static void main(String[] args) {
		
		Product[ ] arr = {
				new Product(3, "Pen", 11.33),
				new Product(4, "Pencil", 5.10),
				new Product(1, "Erasor", 6.66),
				new Product(5, "Sharpner", 7.33),
				new Product(2, "Book", 20.00)
		}; 
		
		for(int i = 0 ; i < arr.length ; i++) {
			System.out.println(arr[i]);
		}
		
		/*class ProductNameComparator implements Comparator<Product>{
			public int compare(Product x,Product y) {
				int diff=x.getName().compareTo(y.getName());
				return diff;
			}
		}
		
		Arrays.sort(arr,new ProductNameComparator());
		System.out.println();
		System.out.println("Sorted on name");
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}*/
		
		class productIdComparator implements Comparator<Product>{
			public int compare(Product x,Product y) {
				int diff=Integer.compare(x.getId(), y.getId());
				return diff;
			}
			}
		System.out.println("Sorting on id:");
		Arrays.sort(arr,new productIdComparator());
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		
		class ProductPriceComparator implements Comparator<Product>{
			public int compare(Product x,Product y) {
				int diff=Double.compare(x.getPrice(), y.getPrice());
				return diff;
			}
		}
		System.out.println("Sorting on price:");
		Arrays.sort(arr,new ProductPriceComparator());
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}

	}

}
