package college.dkte;

import java.util.Arrays;

public class Program {

	public static void main1(String[] args) {
		Product[] arr= {
				new Product(3, "Pen", 11.33),
				new Product(4, "Pencil", 5.10),
				new Product(1, "Erasor", 6.66),
				new Product(5, "Sharpner", 7.33),
				new Product(2, "Book", 20.00)
		};
		
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		
		Arrays.sort(arr);
		System.out.println("Sorted on id:");
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
	}
	
	public static void main2(String[] args) {
		Product02[] arr= {
				new Product02(3, "Pen", 11.33),
				new Product02(4, "Pencil", 5.10),
				new Product02(1, "Erasor", 6.66),
				new Product02(5, "Sharpner", 7.33),
				new Product02(2, "Book", 20.00)
		};
		
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		
		Arrays.sort(arr);
		System.out.println("Sorted on id:");
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
	}
	
	public static void main(String[] args) {
		Product03[] arr= {
				new Product03(3, "Pen", 11.33),
				new Product03(4, "Pencil", 5.10),
				new Product03(1, "Erasor", 6.66),
				new Product03(5, "Sharpner", 7.33),
				new Product03(2, "Book", 20.00)
		};
		
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		
		Arrays.sort(arr);
		System.out.println("Sorted on id:");
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
	}
}
