package college.dkte2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

public class Program {

	public static void main(String[] args) {
		//Collection<String> c = new ArrayList<String>();
		Collection<String> c = new LinkedList<String>(); 
		c.add("India"); 
		c.add("USA");
		c.add("India");
		c.add("England");
		c.add("Iran");
		c.add("Isreal");
		c.add("Ukraine"); 
		
		System.out.println("Size : "+c.size());
		
		System.out.println("ele : "+c.toString());
		
		c.remove("USA"); 
		System.out.println("ele : "+c.toString());
		System.out.println();
		System.out.println("FWD traversing : ");
		Iterator<String> trav = c.iterator(); 
		while(trav.hasNext()) {
			String ele = trav.next(); 
			System.out.print(ele + " ");
		}
	}
}
