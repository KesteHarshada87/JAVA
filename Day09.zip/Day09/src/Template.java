
public class Template {
	public static <T> void swap(T a,T b) {
		T temp;
		temp=a;
		a=b;
		b=temp;
		System.out.println("Swapped numbers: "+a+" "+b);
	}
	public static void main(String[] args) {
		swap(10,20);

		swap("H","S");
	}

}
