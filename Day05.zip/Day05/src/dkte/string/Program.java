package dkte.string;

public class Program {

	public static void main(String[] args) {
		Date dt1=new Date(1,1,2004);
		System.out.println("to string:"+dt1.toString());

	}

}
