package dkte.string;

import java.util.Arrays;
public class ArrayToString {

	public static void main(String[] args) {
		int arr[]= {1,5,2,33,8,9};
		
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		
		System.out.println(""+Arrays.toString(arr));
		System.out.println("After sorting:");
		
		Arrays.sort(arr);
		
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
	}

}
