package dkte.college;
import java.util.Scanner;
class Shape2 {
	protected double area;
	public void calculateArea() {
		
	}
	public double getArea() {
		return area;
	}
}

class Rectangle1 extends Shape2{
	private float length;
	private float breadth;
	Rectangle1 rect=new Rectangle1();
	public void setLength(float length) {
		this.length=length;
	}
	public void setBreadth(float breadth) {
		this.breadth=breadth;
	}
	
	public void calculateArea() {
		this.area=this.length*this.breadth;
	}
}

class Circle1 extends Shape2{
	private int radius;
	Circle1 c=new Circle1();
	public void setRadius(int radius) {
		this.radius=radius;
	}
	
	public void calculateArea() {
		this.area=Math.PI*this.radius*this.radius;
	}
}
public class Instanceof {
	private static Scanner sc = new Scanner(System.in);	
	public static int menuList( ) {
		int choice; 
		System.out.println("0.Exit");
		System.out.println("1.Rectangle");
		System.out.println("2.Circle");
		System.out.print("Enter the choice : ");
		choice = sc.nextInt(); 
		return choice; 
	}
	
	public static void acceptRecord(Shape2 shape2) {
		
		if(shape2 instanceof Rectangle1) {
			Rectangle1 rect=(Rectangle1) shape2;//downcasting
			System.out.println("Length:");
			rect.setLength(sc.nextFloat());
			System.out.println("Breadth:");
			rect.setBreadth(sc.nextFloat());
			
		}
		
		else if(shape2 instanceof Circle1) {
			Circle1 c=(Circle1) shape2;//downcasting
			System.out.println("Radius");
			c.setRadius(sc.nextInt());
		}
		
		else {
			System.out.println("Invalid choice!");
		}
	}
		public static void printRecord(Shape2 shape2) {
			System.out.println("Area:"+shape2.area);
		}
	
	public static void main(String[] args) {
		int choice; 
		while((choice = menuList())!=0) {
			Shape2 shape2 = null; 
			switch (choice) {
			case 1:
				shape2 = new Rectangle1(); // upcasting  
				break;
			case 2: 
				shape2 = new Circle1(); // upcasting 
				break; 
			default:
				System.out.println("Invalid choice");
				break;
			}
			if(shape2!=null) {
				Instanceof.acceptRecord(shape2);
				shape2.calculateArea();
				Instanceof.printRecord(shape2);
			}
		}

	}

}
