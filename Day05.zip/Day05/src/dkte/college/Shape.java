package dkte.college;
import java.util.Scanner;
class Shape1{
	protected float area;
	
	public void acceptRecord() {
		//100% incomplete
	}
	public void calculateArea() {
		//100% incomplete
	}
	public void printRecord() {
		System.out.println("Area is:"+this.area);
	}
}

class Rectangle extends Shape1{
	private int length;
	private int breadth;
	
	public Rectangle() {
		
	}
	
	public void acceptRecord() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter length:");
		length=sc.nextInt();
		System.out.println("Enter breadth:");
		breadth=sc.nextInt();
	}
	public void calculateArea() {
		this.area=this.length*this.breadth;
	}
	
}

class Circle extends Shape1{
	private int radius;
	private final double PI=3.14;
	
	public Circle() {
		
	}
	
	public void acceptRecord() {
		Scanner sc=new Scanner(System.in);
		radius=sc.nextInt();
	}
	public void calculateArea() {
		this.area=(float)(Math.PI*this.radius*this.radius);
	}
}
public class Shape {
	public static int menuList() {
		Scanner sc=new Scanner(System.in);
		int choice;
		System.out.println("Enter your choice:");
		System.out.println("0.Exit");
	
		System.out.println("1.Rectangle");

		System.out.println("2.Circle");
	   
	    System.out.println("Enter your choice:");
	    choice=sc.nextInt();
		return choice;
 	   
    }
	public static void main(String[] args) {
       int choice;
       while((choice=menuList())!=0) {
    	   Shape1 shape1=null;
    	   switch (choice) {
    	   case 1:
    		   shape1=new Rectangle();//upcasting
    		   break;
    	   case 2:
    		   shape1=new Circle();//upcasting
    		   break;
    	   default:
    		   System.out.println("Invalid choice");
    		   
    	   }
    	   if(shape1!=null) {
    		   shape1.acceptRecord();//dynamic method dispatch
    		   shape1.calculateArea();
    		   shape1.printRecord();
    	   }
       }

	}

}
