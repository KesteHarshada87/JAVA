package dkte.college;

class A{
	public void showRecord() {
		System.out.println("A.showRecord()");
	}
	
	public void printRecord() {
		System.out.println("A.printRecord()");
	}
}

class B extends A{
	public void printRecord() {
		System.out.println("B.printRecord()");
	}
	
	public void displayRecord() {
		System.out.println("B.displayRecord()");
	}
}
public class DynamicMethodDispatch {

	public static void main(String[] args) {
		A ref=new B();//upcasting
		ref.showRecord();
		ref.printRecord();//dynamic method dispatch
		
		B ref1=(B) ref;//downcasting
		ref1.displayRecord();
		ref1.printRecord();

	}

}
