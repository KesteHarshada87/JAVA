
public class Addition {

	public static void main(String[] args) {
		int a=7,b=8,c;
	    c=a+b;
		System.out.println("Sum is:"+c);

	}

}
