package dakte.college1;

import java.util.Stack;

public class Stack_Simple {

	public static void main(String[] args) {
		Stack<String> stk=new Stack<String>();
		
		stk.push("one");
		stk.push("two");
		stk.push("three");
		stk.push("four");
		stk.push("five");
		
		while(!stk.isEmpty()) {
			String ele=stk.pop();
			System.out.println(ele);
		}

	}

}
