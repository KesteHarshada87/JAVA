package dakte.college1;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

public class Priorityqueue {

	public static void main1(String[] args) {
		Queue<String> q=new PriorityQueue<String>();//(Elements are retrieved as per priority -- decided by Comparable (Natural Ordering)
		
		q.offer("D");
		q.offer("K");
		q.offer("T");
		q.offer("E");
		
		while(!q.isEmpty()) {
			String ele=q.poll();
			System.out.println(ele);
		}
	}
	
	public static void main(String[] args) {
		Queue<String> q=new PriorityQueue<String>();
		
		q.offer("D");
		q.offer("K");
		q.offer("T");
		q.offer("E");
		
		class PriorityQueueComparator implements Comparator<String>{
			public int compare(String x,String y) {
				int diff=x.compareTo(y);
				return diff;
			}
		}
		
		while(!q.isEmpty()) {
			String ele1=q.poll();
			System.out.println(ele1);
		}
	}
}
