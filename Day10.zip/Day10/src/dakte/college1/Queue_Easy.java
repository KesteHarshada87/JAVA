package dakte.college1;

import java.util.ArrayDeque;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Iterator;

public class Queue_Easy {

	public static void main1(String[] args) {
		Queue<String> a=new ArrayDeque<String>();
		//Queue<String> a=new LinkedList<String>();
		
		a.offer("one");
		a.offer("two");
		a.offer("three");
		a.offer("four");
		a.offer("five");
		
		System.out.println("Forward traversing:");
		Iterator<String> trav=a.iterator();
		while(!a.isEmpty()) {
			String ele=a.poll();
			System.out.println(ele);
		}
		
		System.out.println("Removing element from queue:"+a.poll());

		
	}
	
	public static void main(String[] args) {
		Queue<String> a=new ArrayDeque<String>();
		//Queue<String> a=new LinkedList<String>();
		
		a.offer("one");
		a.offer("two");
		a.offer("three");
		a.offer("four");
		a.offer("five");
		
		System.out.println("First element:"+a.peek());
		
		while(!a.isEmpty()) {
			String ele=a.remove();
			System.out.println(ele);
		}
		
		System.out.println("Removing element from queue:"+a.remove());

		
	}

}
