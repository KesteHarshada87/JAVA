package dakte.college1;

import java.util.Iterator;
import java.util.List;
import java.util.Collections;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Vector;;

public class List1 {

	public static void main(String[] args) {
		ArrayList<Integer> list=new ArrayList<Integer>();
		//LinkedList<Integer> list=new LinkedList<Integer>();
		//Vector<Integer> list=new Vector<Integer>();
		
		Collections.addAll(list, 10,20,30,40,50);
		
		for(Integer l:list) {
			System.out.println(l);
		}
		
		Collections.shuffle(list);
		System.out.println(list);
		
		System.out.println("Forward traversing:");
		Iterator<Integer> trav=list.iterator();
		while(trav.hasNext()) {
			Integer ele=trav.next();
				System.out.println(ele);
		}
		
		
		System.out.println();
		System.out.println("For loop");
		for(int i=0;i<list.size();i++) {
			Integer ele1=list.get(i);
			System.out.println(ele1);
		}
	}

}
