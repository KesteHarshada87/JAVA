package dakte.college;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;


public class Program {

	public static void main(String[] args) {
		List<Book> list=new ArrayList<Book>();
		
		Collections.addAll(list,
			    new Book(4, "The Alchemist", "Novel", 493.23),
			    new Book(1, "The Archer", "Novel", 723.53),
			    new Book(5, "The Fountainhead", "Novel", 652.73),
			    new Book(2, "Atlas Shrugged", "Novel", 872.94),
			    new Book(6, "Harry Potter", "Novel", 423.68),
			    new Book(3, "Lord of Rings", "Novel", 621.53)	
			); 
		
		for(Book b:list) {
			System.out.println(b);
		}
		
		int index=3;
		Book b=list.get(index);
		System.out.println();
		System.out.println(b);
		
		System.out.println("Forward traversing:");
		Iterator<Book> trav=list.iterator();
		while(trav.hasNext()) {
			Book ele=trav.next();
			System.out.println();
			System.out.println("Elements:"+ele);
		}
		
		System.out.println();
		int id=5;
		Book key=new Book();
		key.setId(id);
		
		/*int idx = list.indexOf(key); 
		System.out.println();
		if(idx!=-1) {
			Book bk=list.get(idx);
			System.out.println();
			System.out.println(bk+" found at:"+idx);
			
		}
		else {
			System.out.println("Not found");
		}*/
		
		/*Collections.sort((List<T>) list); //natural ordering 
		System.out.println("Sort on ID : ");
		for(Book bkk : list) {
			System.out.println(bkk);
		}*/
		
		class BookNameComparator implements Comparator<Book>{
			public int compare(Book x,Book y) {
				int diff=x.getName().compareTo(y.getName());
				return diff;
			}
		}
		
		System.out.println("Name: ");
		Collections.sort(list,new BookNameComparator());
		for(Book b1:list) {
			System.out.println(b1);
		}
		
		class BookPriceComparator implements Comparator<Book>{
			public int compare(Book a,Book b) {
				//int diff1=a.getPrice().compareTo(b.getPrice());//can't invock primitive on compareTo()
				int diff1=Double.compare(a.getPrice(),b.getPrice());
				return diff1;
			}
		}
		
		System.out.println("Price");
		Collections.sort(list,new BookPriceComparator());
		for(Book b2:list) {
			System.out.println(b2);
		}
		
		class BookSubjectComparator implements Comparator<Book>{
			public int compare(Book c,Book d) {
				int diff3=c.getSubject().compareTo(d.getSubject());
				return diff3;
			}
		}
		
		System.out.println("Subject: ");
		for(Book b3:list) {
			System.out.println(b3);
		}
	}

}
