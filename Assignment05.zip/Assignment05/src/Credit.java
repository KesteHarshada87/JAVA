import java.util.Scanner;

class Customers{
	//once declare don't declare another time
	// array of Customer objects
	Customers[] customers;
	protected int accNo;
	protected int bBalance;
	protected int tCharge;
	protected int tCredits;
	protected int limit;
	
	int count;

	public void acceptRecord() {
		System.out.println("Enter count of customers:");
		Scanner sc=new Scanner(System.in);
		count=sc.nextInt();
		customers=new Customers[count];// initialize array
		
		for(int i=0;i<count;i++) {
			
			customers[i]=new Customers();// create each Customer object
			
			System.out.println("Enter account number:");
			customers[i].accNo=sc.nextInt();
			
			System.out.println("Enter beginning balance:");
			customers[i].bBalance=sc.nextInt();
			
			System.out.println("Enter total of all items charged by the customer this month:");
			customers[i].tCharge=sc.nextInt();
			
			System.out.println("Enter total of all credits applied to the customer’s account this month:");
			customers[i].tCredits=sc.nextInt();
			
			System.out.println("Enter allowed credit limit:");
			customers[i].limit=sc.nextInt();
		}
	}
	
	public void displayRecord() {
		System.out.println("Customer's details:");
		
		for(int i=0;i<count;i++) {
		
		int newBalance=customers[i].bBalance+customers[i].tCharge-customers[i].limit;
		
		if(newBalance>customers[i].limit) {
			System.out.println("Credit limit exceeded!!");
		}
		else {
			System.out.println("Within the credit limit!!");
		}
	}
	}
}

public class Credit {

	public static void main(String[] args) {
		Customers c=new Customers();
		c.acceptRecord();
		c.displayRecord();

	}

}