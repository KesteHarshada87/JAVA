import java.util.Scanner;
public class TryWithResource {

	public static void main(String[] args) {
		//try with resource--java7.0
		try(Scanner sc=new Scanner(System.in)){
			System.out.println("Enter a number");
			int num=sc.nextInt();
			System.out.println("Square:"+num*num);
		}//sc.close()

	}

}
