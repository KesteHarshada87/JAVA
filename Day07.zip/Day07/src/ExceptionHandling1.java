import java.util.InputMismatchException;
import java.util.Scanner;
public class ExceptionHandling1 {
	
	public static int divide(int num,int den) {
		return num/den;
		
	}

	public static void main(String[] args) {
		try {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter numerator:");
		int num=sc.nextInt();
		System.out.println("Enter denominator:");
		int den=sc.nextInt();
		int result=divide(num,den);
		System.out.println(result);
		}
		catch(InputMismatchException e) {
			System.out.println("Divide by zero");
			
		}
		catch(ArithmeticException e) {
			System.out.println("Invalid I/p");
		}

	}

}
