import java.util.Scanner;
import java.util.InputMismatchException;
public class ExceptionHandling2 {
	
	private static final Scanner sc = null;
	public static int divide(int num,int den) {
		int res=num/den;
		return res;
		
	}
	public static void main(String[] args) {
		try {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter numerator:");
			int num=sc.nextInt();
			System.out.println("Enter denominator:");
			int den=sc.nextInt();
			int result=divide(num,den);
			System.out.println("Result:"+result);
		}
		catch(ArithmeticException | InputMismatchException e) {
			System.out.println("Invalid input!");
		}finally {
			sc.close(); // resource closed
		}

	}

}
