import java.util.Scanner;
public class GetMessage {
	public static int divide(int num,int den) {
		return num/den;
	}
	public static void main(String[] args) {
		try {
			Scanner sc=new Scanner(System.in);
			System.out.println("Numerator");
			int num=sc.nextInt();
			System.out.println("Denominator:");
			int den=sc.nextInt();
			int result=divide(num,den);
			System.out.println(result);
		}
		catch(Throwable e) {
			System.out.println("Message: "+e.getMessage());
		}

	}

}
