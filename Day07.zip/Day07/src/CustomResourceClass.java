
public class CustomResourceClass {

	public static void main(String[] args) {
		class MyResource implements AutoCloseable{
			
			public MyResource() {
				System.out.println("My resource created!");
			}
			
			//override
			public void close() {
				System.out.println("Resource closed!");
			}
			
			
		}
		try(MyResource myResource=new MyResource() ){
			System.out.println("My resource clased");
		}

	}

}
