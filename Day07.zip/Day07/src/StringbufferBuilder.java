
public class StringbufferBuilder {

	public static void main(String[] args) {
		/*StringBuffer sb=new StringBuffer();
		sb.append("Harshada");
		sb.append(20);
		sb.append(10000.00);
		sb.append(true);
		
		String str=sb.toString();
		System.out.println(str);*/
		
		StringBuffer sb=new StringBuffer();
		System.out.println("capacity: "+sb.capacity()+" length:"+sb.length());
		sb.append(973884.1008);
		System.out.println("capacity: "+sb.capacity()+" length:"+sb.length());
		sb.append("Harshada Keste");
		System.out.println("capacity: "+sb.capacity()+" length:"+sb.length());
		sb.append(1234567890);
		System.out.println("capacity: "+sb.capacity()+" length:"+sb.length());
		
		StringBuilder sb1=new StringBuilder("Sunbeam");
		sb1.reverse();
		System.out.println(sb1);
		
		String s1="Sunbeam";
		String s2="Sunbeam";
		System.out.println("Equals: "+s1.equals(s2));
		
		String s="Sunbeam";
		StringBuffer sb3=new StringBuffer("Sunbeam");
		System.out.println("Equals: "+s.equals(sb3));//output will be false
		
		System.out.println("Equals: "+s.equals(sb3.toString()));
	}

}
