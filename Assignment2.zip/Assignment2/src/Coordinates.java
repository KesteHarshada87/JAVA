import java.util.Scanner;
class Point2D{
	private int x1,x2;
	private int y1,y2;
	
	public Point2D() {
		
	}
	public Point2D(int x1,int x2,int y1,int y2) {
		this.x1=x1;
		this.y1=y1;
		this.x2=x2;
		this.y2=y2;
	}
	
	public int getX1() {
		return x1;
	}
	public void setX1(int x1) {
		this.x1=x1;
	}
	
	public int getY1() {
		return y1;
	}
	public void setY1(int y1) {
		this.y1=y1;
	}
	
	public int getX2() {
		return x2;
	}
	public void setX2(int x2) {
		this.x2=x2;
	}
	
	public int getY2() {
		return y2;
	}
	public void setY2(int y2) {
		this.y2=y2;
	}
	
}

class TestPoint2D{
	Point2D p=new Point2D();
	public void acceptRecord() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter x1:");
		p.setX1(sc.nextInt());
		System.out.println("Enter y1:");
		p.setY1(sc.nextInt());
		
		System.out.println("Enter x2:");
		p.setX2(sc.nextInt());
		System.out.println("Enter y2:");
		p.setY2(sc.nextInt());
	}
	
	public void showRecord() {
		String str1=Integer.toString(p.getX1());
		System.out.println("In string format x1:"+str1);
		
		String str2=Integer.toString(p.getY1());
		System.out.println("In string format y1:"+str2);
		
		String str3=Integer.toString(p.getX2());
		System.out.println("In string format x2:"+str3);
		
		String str4=Integer.toString(p.getY2());
		System.out.println("In string format y2:"+str4);
	}
	
	public void comparePoints() {
	//if(Objects.equals(x,y)--this is another way but here int is premitive
	/*if(p.getX1()==p.getX2() && p.getY1()==p.getY2()) {
		System.out.println("Both points are equal");
	}*/
	if (Integer.valueOf(p.getX1()).equals(Integer.valueOf(p.getX2())) &&
		    Integer.valueOf(p.getY1()).equals(Integer.valueOf(p.getY2()))) {
		      System.out.println("Both points are equal.");
		 } 	
		
	else {
		double distance=Math.sqrt(Math.pow(p.getX2()-p.getX1(), 2)+Math.pow(p.getY2()-p.getY1(), 2));
		System.out.println("Distance between two points:"+distance);
	}
	}
}


public class Coordinates {

	public static void main(String[] args) {
		TestPoint2D t1=new TestPoint2D();
		t1.acceptRecord();
		t1.comparePoints();

	}

}