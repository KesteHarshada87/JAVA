import java.util.Calendar;
import java.util.Scanner;

class Date{
	private int day;
	private int month;
	private int year;
	
	public Date() {
		Calendar c=Calendar.getInstance();
		day=c.get(Calendar.DATE);
		month=c.get(Calendar.MONTH)+1;
		year=c.get(Calendar.YEAR);
	}
	
	public Date(int day,int month,int year) {
		this.day=day;
		this.month=month;
		this.year=year;
	}
	
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day=day;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month=month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year=year;
	}
	
	public void displayDate() {
		System.out.print(""+day+"/");
		System.out.print(""+month+"/");
		System.out.println(""+year);
	}
}

class TestDate{
	Date dt2=new Date();
	public void acceptRecord() {
		Scanner sc =new Scanner (System.in);
		System.out.println("Day:");
		dt2.setDay(sc.nextInt());
		System.out.println("Month:");
		dt2.setMonth(sc.nextInt());
		System.out.println("Year:");
		dt2.setYear(sc.nextInt());
	}
	public void printRecord() {
		System.out.println("Day:"+dt2.getDay());
		System.out.println("Month"+dt2.getMonth());
		System.out.println("Year:"+dt2.getYear());
	}
}
public class Assignment1Q {

	public static void main(String[] args) {
		Date dt1=new Date();
		dt1.displayDate();
        TestDate dt2=new TestDate();
        dt2.acceptRecord();
        dt2.printRecord();
	}

}