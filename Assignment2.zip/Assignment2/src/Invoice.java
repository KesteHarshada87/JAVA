
import java.util.Scanner;

class Invoice1{
	private String apartNum;
	private String apartDes;
	private int item;
	private double price;
	
	public Invoice1() {
		
	}
	public Invoice1(String apartNum,String apartDes,int item,double price) {
		this.apartNum=apartNum;
		this.apartDes=apartDes;
		this.item=item;
		this.price=price;
	}
	
	public String getApartNum() {
		return apartNum;
	}
	public void setApartNum(String apartNum) {
		this.apartNum=apartNum;
	}
	public String getApartDes() {
		return apartDes;
	}
	public void setApartDes(String apartNum) {
		this.apartDes=apartDes;
	}
	public int getItem() {
		return item;
	}
	public void setItem(int item) {
		this.item=item;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price=price;
	}
	
}

class TestInvoice1{
	Invoice1 i1=new Invoice1();
	public void acceptRecord() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter apartment number:");
		i1.setApartNum(sc.nextLine());
		System.out.println("Enter apartment description:");
		i1.setApartDes(sc.nextLine());
		System.out.println("Enter number of items:");
		i1.setItem(sc.nextInt());
		System.out.println("Enter price:");
		i1.setPrice(sc.nextDouble());
	}
	
	public void printRecord() {
		System.out.println("Number of items:"+i1.getItem());
		if(+i1.getItem()>0) {
			System.out.println("You have entered positive count of items!!");
		}
		else {
			System.out.println("You entered negative value of item!!");
		}
		System.out.println("Price is:"+i1.getPrice());
		if(+i1.getPrice()>0) {
			System.out.println("Total price is:"+i1.getPrice()*i1.getItem());
		}
		else {
			System.out.println("You have entered negative value of price!!");
		}
	}
	
}
public class Invoice {

	public static void main(String[] args) {
		Invoice1 i=new Invoice1();
		TestInvoice1 i2=new TestInvoice1();
		i2.acceptRecord();
		i2.printRecord();
       
	}

}