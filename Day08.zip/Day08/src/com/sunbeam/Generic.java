package com.sunbeam;


class Box{
	private Object obj;
	
	public Object getObj() {
		return obj;
	}
	public void setObj(Object obj) {
		this.obj=obj;
	}
}
public class Generic {

	public static void main(String[] args) {
		Box b1=new Box();
		b1.setObj(new Double(3.1));
		Double r1=(Double) b1.getObj();
		System.out.println("r1: "+r1);
		
		Box b2=new Box();
		b2.setObj(new Integer(8));
		Integer r2=(Integer) b2.getObj();
		System.out.println("r2: "+r2);
		
		Box b4 = new Box(); 
		b4.setObj("123");
		String r4 = (String) b4.getObj();
		System.out.println("r4 : "+r4);
		
		Box b5 = new Box(); 
		b5.setObj("100");
		//Integer r5 = (Integer) b5.getObj(); // type-checking at runtime 
		//System.out.println("r5 : "+r5);
	}

}
