package com.sunbeam;
import java.util.Scanner;

enum Arithmetic{
	ADD,SUB,MULT,DIV,MOD
}
public class Enum {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter frist number:");
		int num1=sc.nextInt();
		System.out.println("Enter second number:");
		int num2=sc.nextInt();
		int result;
		Arithmetic[] aritValues=Arithmetic.values();
		for(Arithmetic ar:aritValues) {
			System.out.println(ar.ordinal()+"."+ar.name());
		}
		
		System.out.println("Enter your choice:");
		int index=sc.nextInt();
		
		Arithmetic choice=aritValues[index];
		
		switch (choice) {
		case ADD:
			result = num1 + num2;
			System.out.println("Result: " + result);
			break;
		case SUB:
			result = num1 - num2;
			System.out.println("Result: " + result);
			break;
		case MULT:
			result = num1 * num2;
			System.out.println("Result: " + result);
			break;
		case DIV:
			result = num1 / num2;
			System.out.println("Result: " + result);
			break;
		}

	}

}
