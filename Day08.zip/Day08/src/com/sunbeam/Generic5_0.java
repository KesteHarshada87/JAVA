package com.sunbeam;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
class Box1<T>{
	private T obj;
	
	public T getObj() {
		return obj;
	}
	
	public void setObj(T obj) {
		this.obj=obj;
	}
}

public class Generic5_0 {

	public static void main(String[] args) {
		Box1<Integer> b1=new Box1<Integer>();
		b1.setObj(new Integer(5));
		Integer r1=b1.getObj();
		System.out.println("r1: "+r1);
		
		Box1<Date> b2=new Box1<Date>();
		b2.setObj(new Date());
		Date r2=b2.getObj();
		System.out.println("r2: "+r2);

		Box1<Integer> b4 = new Box1<Integer>(); 
		//b4.setObj("123"); // Type checking at compile time 
		b4.setObj(new Integer(111));
		
		List<Integer> list = new ArrayList<Integer>(); 
		list.add(10); 
		list.add(20); 
		list.add(30); 
		list.add(40); 
		//list.add("90")
		
		for(Integer ele : list) {
			System.out.println(ele);
	}

}
}
