package com.beam;

public class Time {
	int hrs;
	int mins;
	int secs;
	
	public Time() {
		
	}
	public Time(int hrs,int mins,int secs) {
		this.hrs=hrs;
		this.mins=mins;
		this.secs=secs;
	}
	
	public int getHrs() {
		return hrs;
	}
	public void setHrs(int hrs) throws InvalidTimeException{
		if(hrs<0 || hrs>60) {
			throw new InvalidTimeException("hrs",hrs);
		}
		this.hrs=hrs;
	}
	
	public int getMins() {
		return mins;
	}
	public void setMins(int mins) throws InvalidTimeException{
		if(mins<0 || mins>60) {
			throw new InvalidTimeException("mins",mins);
		}
		this.mins=mins;
	}
	
	public int getSecs() {
		return secs;
	}
	public void setSecs(int secs) throws InvalidTimeException {
		if(secs<0 || secs>60) {
			throw new InvalidTimeException("secs",secs);
		}
		this.secs=secs;
	}
	
	public String toString() {
		String string;
		return string="Date[hrs: "+hrs+"mins: "+mins+"secs: "+secs+"]";
	}
}
