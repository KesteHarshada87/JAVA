package com.beam;

public class Program {

	public static void main(String[] args) {
		try {
			Time t=new Time();
			t.setMins(100);
			t.setHrs(1);
			t.setSecs(1);
			System.out.println("t : "+t.toString());
		}catch(InvalidTimeException e) {
			System.out.println("Invalid field:"+e.getInvalidField());
			System.out.println("Invalid value:"+e.getInvalidValue());
			System.out.println("Message:"+e.getMessage());
		}

	}

}
