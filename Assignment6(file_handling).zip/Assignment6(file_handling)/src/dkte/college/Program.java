package dkte.college;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.ArrayList;

public class Program {

	public static void main(String[] args) {
		writeVehicles();
	}
	
	
	public static void writeVehicles() {
		List<Vehicle> list=new ArrayList<>();
		list.add(new Vehicle(1,"MarutiSuzuki Swift","HatchBack",120000));
		list.add(new Vehicle(2,"Hyundai i20","Hatchback",500000));
		list.add(new Vehicle(3,"Mahindra-Thar","SUV",600000));
		list.add(new Vehicle(4,"Toyota-Inova","MPV",780000));
		
		try(FileOutputStream fout=new FileOutputStream ("Vehicle.txt")){
			try(PrintStream out=new PrintStream(fout)){
				for(Vehicle v:list) {
					out.println(v.getVehicleId());
					out.println(v.getModel());
					out.println(v.getType());
					out.println(v.getPrice());
					
				}
			
				System.out.println("Vehicles saved..");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
