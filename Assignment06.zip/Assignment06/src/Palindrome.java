

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string:");
		String str=sc.next();
		StringBuilder sd=new StringBuilder(str);
		sd.reverse();
		
		System.out.println("Using string builder:");
		if(sd.toString().equals(str)) {
			System.out.println("Strings are palindrome");
		}
		else {
			System.out.println("Strings are not palindrome");
		}
		
		
		}
		
		
	

}