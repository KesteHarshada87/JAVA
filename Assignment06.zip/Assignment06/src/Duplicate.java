

public class Duplicate {

	public static void main(String[] args) {
		String[] arr1={"H","A","R","S","H","A","D","A"};
		String[] arr2={"S","H","A","S","H","W","A","T"};
		
		System.out.println();
		
		for(int i=0;i<arr1.length;i++) {
			for(int j=0;j<arr2.length;j++) {
				if(arr1[i].equals(arr2[j])) {
					System.out.println(arr1[i]);
					break;//avoid printing same value multiple times
				}
			}
		}
	}

}