

import java.util.Scanner;
import java.util.PriorityQueue;
import java.util.Arrays;
import java.util.Collections;
import java.util.Stack;
public class ReverseString {

	public static void main(String[] args) {
		System.out.println("Enter string:");
		Scanner sc=new Scanner(System.in);
		String name=sc.next();
		//using charat
		System.out.println("Reversed string using charAt method:");
		for(int i=name.length()-1;i>=0;i--) {
			System.out.print(name.charAt(i));
		}
		
		System.out.println();
		System.out.println();
		System.out.println("Using stack:");
		Stack<String> str1=new Stack();
		str1.push("H");
		str1.push("S");
		str1.push("T");
		str1.push("D");
			
		while(!str1.isEmpty()) {
			System.out.print(str1.pop());
		}
		
		System.out.println();
		System.out.println();
		System.out.println("Using string builder:");
		System.out.println("Enter string:");
		String str2=sc.next();
		StringBuilder sb=new StringBuilder(str2);
		sb.reverse();
		System.out.println("Reversed string:"+sb.toString());
		
	}
	

}